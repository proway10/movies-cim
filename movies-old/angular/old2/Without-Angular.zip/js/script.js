$(function () {
    $("#menu-toggle").click(function (e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });

    if ($(window).width() <= 768) {
        $("#wrapper").removeClass("toggled");
    } else {
        $("#wrapper").addClass("toggled");
    }  
});


let jsonUrl = './data.json';

$('#usersList').DataTable({
    "processing": true, 
    "columnDefs": [
        { "targets": [0, 1, 2, 3], "orderable": false }
    ],
    "order": [[4, "desc"]],
    ajax: {
        url: jsonUrl, 
        dataSrc: ''
    },
    columns: [
        { "data": "fileName" },
        { "data": "first_name" },
        { "data": "last_name" },
        { "data": "email" },
        { "data": "gender" },
        { "data": "ip_address" }
    ],
});
