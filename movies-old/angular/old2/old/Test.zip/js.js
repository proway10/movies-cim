function bySortedValue(obj, callback, context) {
  var tuples = [];

  for (var key in obj) tuples.push([key, obj[key]]);

  tuples.sort(function (a, b) {
    return a[1] > b[1] ? 1 : a[1] < b[1] ? -1 : 0
  });

  var length = tuples.length;
  while (length--) callback.call(context, tuples[length][0], tuples[length][1]);

}

function words(str) {
  return str.split(" ").reduce(function (count, word) {
    count[word] = count.hasOwnProperty(word) ? count[word] + 1 : 1;

    return count;
  }, {});
}


async function fetchData() {
  //let url = '//norvig.com/big.txt';
  let url = 'http://localhost/js_test/big.txt';

  let response = await fetch(url, {
    mode: 'no-cors'
  });

  let text = await response.text();
  text = text.replace(/[^a-zA-Z ]/g, "");

  console.log(text)

  // Import from URL  
  var libarary = words(text);

  // Import from URL
  var sorted_array = [];
  var i = 0;

  bySortedValue(libarary, function (key, value) { 
    sorted_array.push({
      word: key,
      count: value
    });
    i++;
  });

  // Top Ten words 
  sorted_array = sorted_array.slice(1, 11);  
  var final_result = [];

  for (let array_value of sorted_array) { 
      var keyword = array_value.word;
      var count = array_value.count;

      if(keyword!=''){
        var yandexData = await yandex(keyword);

        final_result.push({
          title: keyword,
          count: count,
          yandexData: yandexData
        });
      }
      
  }

  var textedJson = JSON.stringify(final_result, undefined, 4); 

  console.log(textedJson);
  $('#myTextarea').text(textedJson);
}

async function yandex(keyword) {
  
  var key = 'dict.1.1.20170610T055246Z.0f11bdc42e7b693a.eefbde961e10106a4efa7d852287caa49ecc68cf';
  var url = 'https://dictionary.yandex.net/api/v1/dicservice.json/lookup?key=' + key + '&lang=en-ru&text=' + keyword;
  let response = await fetch(url, {
    mode: 'cors'
  });

  console.log(response);

  let text = await response.text();



  text = JSON.parse(text);
  text = text['def'];

  var set = [];

  var total_rows = text.length;
  var word = [];

  for (let val of text) {
    var meanings = [];

    for (let meaning of val.tr) {
      if (meaning.mean !== undefined) {
        meanings.push(meaning.mean[0]['text']);
      }
    }

    word.push({
      'pos': val.pos,
      'means': meanings,
    });

  }

  return word;
}


fetchData();
